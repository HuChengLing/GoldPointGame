package com.bignerdranch.android.goldpoint;

import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    private Button mPlayer1;
    private Button mPlayer2;
    private Button mPlayer3;
    private Button mPlayer4;
    private Button mPlayer5;
    private Button mPlayer6;
    private Button mPlayer7;
    private Button mPlayer8;
    private Button mPlayer9;
    private Button mPlayer10;
    private Button mInputEnd;
    private Button mCheckResult;
    private Button mStart;
    private LinearLayout mPlayer;
    private TextView mContent;
    private String mNumber;
    private List<Player> mPlayerList= new ArrayList<>();
    private double[] mValue = new double[10];
    private int[]mScore = new int[10];
    private SharedPreferences mPref;
    private SharedPreferences.Editor mEditor;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initView();
        setupListeners();
    }
    public void initView()
    {
        mPlayer1 = (Button)findViewById(R.id.play1_btn);
        mPlayer2 = (Button)findViewById(R.id.play2_btn);
        mPlayer3 = (Button)findViewById(R.id.play3_btn);
        mPlayer4 = (Button)findViewById(R.id.play4_btn);
        mPlayer5 = (Button)findViewById(R.id.play5_btn);
        mPlayer6 = (Button)findViewById(R.id.play6_btn);
        mPlayer7 = (Button)findViewById(R.id.play7_btn);
        mPlayer8 = (Button)findViewById(R.id.play8_btn);
        mPlayer9 = (Button)findViewById(R.id.play9_btn);
        mPlayer10 = (Button)findViewById(R.id.play10_btn);
        mPlayer = (LinearLayout)findViewById(R.id.play_linearLayout);
        mStart = (Button)findViewById(R.id.start_btn);
        mCheckResult = (Button)findViewById(R.id.checkResult_btn);
        mInputEnd = (Button)findViewById(R.id.inputEnd_btn);
        mContent = (TextView) findViewById(R.id.content_textView);
        mPlayer.setVisibility(View.GONE);
        mInputEnd.setVisibility(View.GONE);
        mCheckResult.setVisibility(View.GONE);
        mPref = PreferenceManager.getDefaultSharedPreferences(MainActivity.this);
        for(int i=0;i<10;i++)
        {
            Player player = new Player(null,"0");
            mPlayerList.add(i,player);
        }
        Log.i("TAG","test");
        for(int i=0;i<10;i++){
            mScore[i] = mPref.getInt(Integer.toString(i),0);
        }

    }
    public void setupListeners() {

        mStart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mPlayer.setVisibility(View.VISIBLE);
                mInputEnd.setVisibility(View.VISIBLE);
                mCheckResult.setVisibility(View.VISIBLE);
                mStart.setVisibility(View.GONE);
                mContent.setVisibility(View.GONE);
            }
        });

        mPlayer1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog.Builder dialog = new AlertDialog.Builder(MainActivity.this);
                dialog.setMessage("请输入你的数字");
                View mView = LayoutInflater.from(MainActivity.this).inflate(R.layout.input_number_dialog,null);
                final EditText mEditText = (EditText)mView.findViewById(R.id.dialog_editText);
                dialog.setView(mView);

                dialog.setPositiveButton("确定", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                       mNumber = mEditText.getText().toString();
                       mPlayerList.set(0,new Player("1",mNumber));

                    }
                });
                dialog.setNegativeButton("取消", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();

                    }
                });
                dialog.show();
            }
        });
        mPlayer1.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View view) {
                if(mPlayerList.get(0).getNumber()!="0")
                    Toast.makeText(MainActivity.this, mPlayerList.get(0).getNumber(), Toast.LENGTH_SHORT).show();
                else {
                    Toast.makeText(MainActivity.this,"还没有输入数字",Toast.LENGTH_SHORT).show();
                }
                    return false;
            }
        });


        mPlayer2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                    AlertDialog.Builder dialog = new AlertDialog.Builder(MainActivity.this);
                    dialog.setMessage("请输入你的数字");
                    View mView = LayoutInflater.from(MainActivity.this).inflate(R.layout.input_number_dialog,null);
                    final EditText mEditText = (EditText)mView.findViewById(R.id.dialog_editText);
                    dialog.setView(mView);

                    dialog.setPositiveButton("确定", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            mNumber = mEditText.getText().toString();
                            mPlayerList.set(1,new Player("2",mNumber));

                        }
                    });
                    dialog.setNegativeButton("取消", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.dismiss();

                        }
                    });
                    dialog.show();
            }
        });
        mPlayer2.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View view) {
                if (mPlayerList.get(1).getNumber()!="0"){
                    Toast.makeText(MainActivity.this,mPlayerList.get(1).getNumber(),Toast.LENGTH_SHORT).show();
                }
                else {
                    Toast.makeText(MainActivity.this,"还没有输入数字",Toast.LENGTH_SHORT).show();
                }

                return false;
            }
        });
        mPlayer3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog.Builder dialog = new AlertDialog.Builder(MainActivity.this);
                dialog.setMessage("请输入你的数字");
                View mView = LayoutInflater.from(MainActivity.this).inflate(R.layout.input_number_dialog,null);
                final EditText mEditText = (EditText)mView.findViewById(R.id.dialog_editText);
                dialog.setView(mView);

                dialog.setPositiveButton("确定", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        mNumber = mEditText.getText().toString();
                        mPlayerList.set(2,new Player("3",mNumber));

                    }
                });
                dialog.setNegativeButton("取消", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();

                    }
                });
                dialog.show();
            }
        });
        mPlayer3.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View view) {
                if (mPlayerList.get(2).getNumber()!="0"){
                    Toast.makeText(MainActivity.this,mPlayerList.get(2).getNumber(),Toast.LENGTH_SHORT).show();
                }
                else {
                    Toast.makeText(MainActivity.this,"还没有输入数字",Toast.LENGTH_SHORT).show();
                }
                return false;
            }
        });
        mPlayer4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog.Builder dialog = new AlertDialog.Builder(MainActivity.this);
                dialog.setMessage("请输入你的数字");
                View mView = LayoutInflater.from(MainActivity.this).inflate(R.layout.input_number_dialog,null);
                final EditText mEditText = (EditText)mView.findViewById(R.id.dialog_editText);
                dialog.setView(mView);

                dialog.setPositiveButton("确定", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        mNumber = mEditText.getText().toString();
                        mPlayerList.set(3,new Player("4",mNumber));

                    }
                });
                dialog.setNegativeButton("取消", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();

                    }
                });
                dialog.show();
            }
        });
        mPlayer4.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View view) {
                if (mPlayerList.get(3).getNumber()!="0"){
                    Toast.makeText(MainActivity.this,mPlayerList.get(3).getNumber(),Toast.LENGTH_SHORT).show();
                }
                else {
                    Toast.makeText(MainActivity.this,"还没有输入数字",Toast.LENGTH_SHORT).show();
                }
                return false;
            }
        });
        mPlayer5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog.Builder dialog = new AlertDialog.Builder(MainActivity.this);
                dialog.setMessage("请输入你的数字");
                View mView = LayoutInflater.from(MainActivity.this).inflate(R.layout.input_number_dialog,null);
                final EditText mEditText = (EditText)mView.findViewById(R.id.dialog_editText);
                dialog.setView(mView);

                dialog.setPositiveButton("确定", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        mNumber = mEditText.getText().toString();
                        mPlayerList.add(4,new Player("5",mNumber));

                    }
                });
                dialog.setNegativeButton("取消", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();

                    }
                });
                dialog.show();
            }
        });
        mPlayer5.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View view) {
                if (mPlayerList.get(4).getNumber()!="0"){
                    Toast.makeText(MainActivity.this,mPlayerList.get(4).getNumber(),Toast.LENGTH_SHORT).show();
                }
                else {
                    Toast.makeText(MainActivity.this,"还没有输入数字",Toast.LENGTH_SHORT).show();
                }
                return false;
            }
        });
        mPlayer6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog.Builder dialog = new AlertDialog.Builder(MainActivity.this);
                dialog.setMessage("请输入你的数字");
                View mView = LayoutInflater.from(MainActivity.this).inflate(R.layout.input_number_dialog,null);
                final EditText mEditText = (EditText)mView.findViewById(R.id.dialog_editText);
                dialog.setView(mView);

                dialog.setPositiveButton("确定", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        mNumber = mEditText.getText().toString();
                        mPlayerList.set(5,new Player("6",mNumber));

                    }
                });
                dialog.setNegativeButton("取消", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();

                    }
                });
                dialog.show();
            }
        });
        mPlayer6.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View view) {
                if (mPlayerList.get(5).getNumber()!="0"){
                    Toast.makeText(MainActivity.this,mPlayerList.get(5).getNumber(),Toast.LENGTH_SHORT).show();
                }
                else {
                    Toast.makeText(MainActivity.this,"还没有输入数字",Toast.LENGTH_SHORT).show();
                }
                return false;
            }
        });
        mPlayer7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog.Builder dialog = new AlertDialog.Builder(MainActivity.this);
                dialog.setMessage("请输入你的数字");
                View mView = LayoutInflater.from(MainActivity.this).inflate(R.layout.input_number_dialog,null);
                final EditText mEditText = (EditText)mView.findViewById(R.id.dialog_editText);
                dialog.setView(mView);

                dialog.setPositiveButton("确定", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        mNumber = mEditText.getText().toString();
                        mPlayerList.set(6,new Player("7",mNumber));

                    }
                });
                dialog.setNegativeButton("取消", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();

                    }
                });
                dialog.show();
            }
        });
        mPlayer7.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View view) {
                if (mPlayerList.get(6).getNumber()!="0"){
                    Toast.makeText(MainActivity.this,mPlayerList.get(6).getNumber(),Toast.LENGTH_SHORT).show();
                }
                else {
                    Toast.makeText(MainActivity.this,"还没有输入数字",Toast.LENGTH_SHORT).show();
                }
                return false;
            }
        });
        mPlayer8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog.Builder dialog = new AlertDialog.Builder(MainActivity.this);
                dialog.setMessage("请输入你的数字");
                View mView = LayoutInflater.from(MainActivity.this).inflate(R.layout.input_number_dialog,null);
                final EditText mEditText = (EditText)mView.findViewById(R.id.dialog_editText);
                dialog.setView(mView);

                dialog.setPositiveButton("确定", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        mNumber = mEditText.getText().toString();
                        mPlayerList.set(7,new Player("8",mNumber));

                    }
                });
                dialog.setNegativeButton("取消", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();

                    }
                });
                dialog.show();
            }
        });
        mPlayer8.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View view) {
                if (mPlayerList.get(7).getNumber()!="0"){
                    Toast.makeText(MainActivity.this,mPlayerList.get(7).getNumber(),Toast.LENGTH_SHORT).show();
                }
                else {
                    Toast.makeText(MainActivity.this,"还没有输入数字",Toast.LENGTH_SHORT).show();
                }
                return false;
            }
        });
        mPlayer9.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog.Builder dialog = new AlertDialog.Builder(MainActivity.this);
                dialog.setMessage("请输入你的数字");
                View mView = LayoutInflater.from(MainActivity.this).inflate(R.layout.input_number_dialog,null);
                final EditText mEditText = (EditText)mView.findViewById(R.id.dialog_editText);
                dialog.setView(mView);

                dialog.setPositiveButton("确定", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        mNumber = mEditText.getText().toString();
                        mPlayerList.set(8,new Player("9",mNumber));

                    }
                });
                dialog.setNegativeButton("取消", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                       dialog.dismiss();

                    }
                });
                dialog.show();
            }
        });
        mPlayer9.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View view) {
                if (mPlayerList.get(8).getNumber()!="0"){
                    Toast.makeText(MainActivity.this,mPlayerList.get(8).getNumber(),Toast.LENGTH_SHORT).show();
                }
                else {
                    Toast.makeText(MainActivity.this,"还没有输入数字",Toast.LENGTH_SHORT).show();
                }
                return false;
            }
        });
        mPlayer10.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog.Builder dialog = new AlertDialog.Builder(MainActivity.this);
                dialog.setMessage("请输入你的数字");
                View mView = LayoutInflater.from(MainActivity.this).inflate(R.layout.input_number_dialog,null);
                final EditText mEditText = (EditText)mView.findViewById(R.id.dialog_editText);
                dialog.setView(mView);

                dialog.setPositiveButton("确定", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        mNumber = mEditText.getText().toString();
                        mPlayerList.add(9,new Player("10",mNumber));

                    }
                });
                dialog.setNegativeButton("取消", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();

                    }
                });
                dialog.show();
            }
        });
        mPlayer10.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View view) {
                if (mPlayerList.get(9).getNumber()!="0"){
                    Toast.makeText(MainActivity.this,mPlayerList.get(9).getNumber(),Toast.LENGTH_SHORT).show();
                }
                else {
                    Toast.makeText(MainActivity.this,"还没有输入数字",Toast.LENGTH_SHORT).show();
                }
                return false;
            }
        });
        mInputEnd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int i = 0;
                for(;i<10;i++){
                    if(mPlayerList.get(i).getNumber()=="0")
                        break;
                }

                if(i!=10)
                {
                    Toast.makeText(MainActivity.this,"还没有输完，请继续输入",Toast.LENGTH_SHORT).show();
                }
                else {
                    Toast.makeText(MainActivity.this,"输入完成",Toast.LENGTH_SHORT).show();
                }
            }
        });
        mCheckResult.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int j=0;
                for(;j<10;j++){
                    if(mPlayerList.get(j).getNumber()=="0")
                        break;
                }
                if (j==10)
                {
                     final AlertDialog.Builder dialog = new AlertDialog.Builder(MainActivity.this);
                    dialog.setMessage("游戏结果");
                    View mView = LayoutInflater.from(MainActivity.this).inflate(R.layout.game_result_dialog,null);
                    Button mPlayerScore = (Button)mView.findViewById(R.id.playerScore_btn);
                    Button mCheckGnumber = (Button)mView.findViewById(R.id.checkG_btn);
                    Button mAgainGame = (Button)mView.findViewById(R.id.againGame_btn);
                    Button mRestart = (Button)mView.findViewById(R.id.reStart_btn);
                    dialog.setView(mView);
                    int num=0;
                    float avg;
                    final Double goal;
                    for(int i=0;i<10;i++)
                    {
                        num = num+Integer.parseInt( mPlayerList.get(i).getNumber());
                    }
                    avg = num/10;
                    goal = avg*0.618;
                    for(int i=0;i<10;i++)
                    {
                        if((double)(Integer.parseInt(mPlayerList.get(i).getNumber()))>goal){
                            mValue[i] = Integer.parseInt(mPlayerList.get(i).getNumber())-goal;
                        }
                        else {
                            mValue[i] = goal - Integer.parseInt(mPlayerList.get(i).getNumber());
                        }
                    }
                    double min= mValue[0];
                    double max= mValue[0];
                    int minIndex =0 ;
                    int maxIndex = 0;
                    for(int i=0;i<10;i++)
                    {
                        if(max<mValue[i])
                        {
                            max = mValue[i];
                            maxIndex = i;
                        }
                        if(min>mValue[i])
                        {
                            min = mValue[i];
                            minIndex = i;
                        }
                    }
                    for(int i =0;i<10;i++)
                    {
                        if(mValue[i]==mValue[maxIndex])
                            mScore[i]-=1;
                    }
                   for( int i=0;i<10;i++){
                       if(mValue[i]==mValue[minIndex])
                           mScore[i]+=2;
                   }
                    for(int i=0;i<10;i++){
                        mEditor = mPref.edit();
                        mEditor.putInt(Integer.toString(i),mScore[i]);
                        mEditor.apply();
                    }
                    mPlayerScore.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {

                            Intent i = PlayerScoreActivity.newIntent(MainActivity.this,mScore);
                            startActivity(i);
                        }
                    });
                    mCheckGnumber.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {

                            Toast.makeText(MainActivity.this,Double.toString(goal),Toast.LENGTH_LONG).show();

                        }
                    });
                    mAgainGame.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            mPlayerList.clear();
                            Intent i = new Intent(MainActivity.this,MainActivity.class);
                            startActivity(i);
                        }
                    });

                    mRestart.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            mEditor.clear();
                            mEditor.apply();
                            Intent i = new Intent(MainActivity.this,MainActivity.class);
                            startActivity(i);
                        }
                    });
                    dialog.show();
                }
            }
        });

    }

}
