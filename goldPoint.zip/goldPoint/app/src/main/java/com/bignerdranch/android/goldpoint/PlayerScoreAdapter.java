package com.bignerdranch.android.goldpoint;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

/**
 * Created by asus on 2017/9/24.
 */

public class PlayerScoreAdapter extends BaseAdapter {
    private Context mContext;
    private int[] mScore ;
    public PlayerScoreAdapter(Context context,int[] score ){
        super();
        mContext = context;
        mScore = score;
    }
    @Override
    public int getCount() {
        return mScore.length;
    }

    @Override
    public Object getItem(int i) {
        return null;
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        if (view == null) {
            view = LayoutInflater.from(mContext).inflate(R.layout.item_for_player_score_activity,viewGroup,false);
        }
        TextView id = (TextView)view.findViewById(R.id.id_textView);
        TextView score = (TextView)view.findViewById(R.id.score_textView);
        id.setText("编号："+Integer.toString(i+1));
        score.setText("分数: "+Integer.toString(mScore[i]));
        return view;
    }
}
